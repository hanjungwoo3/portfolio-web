// 서비스워커 — 앱을 대신해 시세를 가져온다(가정용 IP).
//
// Yahoo 는 목록에 없다. 가정용 IP 를 429("Edge: Too Many Requests")로 막기 때문에
// 확장으로 보내면 오히려 실패한다 — 앱이 Yahoo 만 클라우드 프록시로 보낸다.
const ALLOWED_HOSTS = new Set([
  "wts-info-api.tossinvest.com",
  "wts-cert-api.tossinvest.com",
  "tossinvest.com",
  "finance.naver.com",
  "m.stock.naver.com",
  "stock.naver.com",
  "polling.finance.naver.com",
  "navercomp.wisereport.co.kr",
  "api.investing.com",
  "yasun.gg",
  "finance.daum.net",
  "production.dataviz.cnn.io",
  "hq.sinajs.cn",
  "stock2.finance.sina.com.cn",
  "moneyland.co.kr",
  "markets.hankyung.com",
  "scanner.tradingview.com",
  // 야후 — 앱은 아직 여기로 안 보낸다(blocksResidentialIp 로 클라우드 프록시행).
  //   가정용 IP 가 정말 막히는지 서비스워커 콘솔에서 직접 시험하려고 열어둔 상태.
  //   v8/chart 는 crumb 이 필요 없지만 v7/quote·quoteSummary 는 필요하다.
  "query1.finance.yahoo.com",
  "query2.finance.yahoo.com",
]);

// ─── Yahoo crumb 인증 ────────────────────────────────────────
// v7/quote·quoteSummary 는 crumb 없이는 401. v8/chart 는 필요 없다(실측).
// 워커와 달리 쿠키를 직접 나를 필요가 없다 — credentials:"include" 로 부르면
// 브라우저 쿠키 저장소가 알아서 유지·전송한다.
const CRUMB_TTL_MS = 30 * 60 * 1000;
let crumbCache = null;   // { crumb, ts }

function needsCrumb(u) {
  return u.hostname.endsWith("yahoo.com") &&
         (u.pathname.includes("/quoteSummary") ||
          u.pathname.includes("/v7/finance/quote") ||
          u.pathname.includes("/v6/finance/quote"));
}

async function getYahooCrumb() {
  if (crumbCache && Date.now() - crumbCache.ts < CRUMB_TTL_MS) return crumbCache.crumb;
  try {
    // 1) 세션 쿠키 발급 — 응답은 안 봐도 된다. 쿠키만 저장소에 들어가면 된다.
    await fetch("https://fc.yahoo.com/", { credentials: "include" }).catch(() => {});
    // 2) crumb 발급 — 위에서 받은 쿠키가 자동으로 실려 나간다.
    const r = await fetch("https://query1.finance.yahoo.com/v1/test/getcrumb",
                          { credentials: "include" });
    if (!r.ok) return null;
    const c = (await r.text()).trim();
    if (!c || c.length > 50) return null;   // 에러 페이지를 crumb 으로 오인하지 않게
    crumbCache = { crumb: c, ts: Date.now() };
    return c;
  } catch {
    return null;
  }
}

// ─── 요청 헤더 재작성 ────────────────────────────────────────
// Origin·Referer 는 fetch() 로 못 바꾼다(브라우저 금지 헤더). 확장 서비스워커도 마찬가지라
// declarativeNetRequest 로 갈아끼운다. 토스는 Origin 이 tossinvest.com 이 아니면 403 이다
// (실측: Origin 없음 200 / chrome-extension:// 403 / tossinvest.com 200).
//
// ⚠️ condition.tabIds = [-1] — '탭에서 나오지 않은 요청', 즉 이 확장이 보낸 것만 대상.
//    이게 없으면 사용자가 브라우저로 토스·네이버를 볼 때까지 헤더가 바뀐다.
// 토스 — 2026-10-22 부터 `_browserId` 쿠키 없으면 400(값은 아무거나). 확장이 보내는 요청엔 브라우저의 토스 쿠키가
//   실리지 않아 확장 사용자 종목이 안 나왔다(사용자 제보 2026-10-23). 확장 시작마다 아무 값 하나를 만들어 직접 싣는다.
const TOSS_BROWSER_ID = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
// 2026-10-29 18:00 경부터 `deviceId=WTS-<32자>` 쿠키도 같이 있어야 200(둘 중 하나만이면 400, 실측) — 값은 아무거나
const TOSS_DEVICE_ID = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
const HEADER_GROUPS = [
  {
    domains: ["wts-info-api.tossinvest.com", "wts-cert-api.tossinvest.com", "tossinvest.com"],
    headers: { Origin: "https://tossinvest.com", Referer: "https://tossinvest.com/", Cookie: `_browserId=${TOSS_BROWSER_ID}; deviceId=WTS-${TOSS_DEVICE_ID}` },
  },
  {
    domains: ["finance.naver.com", "m.stock.naver.com", "stock.naver.com",
              "polling.finance.naver.com", "navercomp.wisereport.co.kr"],
    headers: { Referer: "https://finance.naver.com/", "Accept-Language": "ko-KR,ko;q=0.9" },
  },
  { domains: ["yasun.gg"], headers: { Referer: "https://yasun.gg/" } },
  { domains: ["finance.daum.net"], headers: { Referer: "https://finance.daum.net/" } },
  { domains: ["hq.sinajs.cn", "stock2.finance.sina.com.cn"], headers: { Referer: "https://finance.sina.com.cn/" } },   // 리튬·니켈 — 없으면 403
  {
    domains: ["markets.hankyung.com"],   // 한경 선물·옵션 — 사이트 공개 키 없으면 403
    headers: { Authorization: "Bearer 0ZdNlr7LrQoawewqweq78k6usasBsqhqSIaUarSTf8mxnHuQVh9CvKAfpUy94LhBmZMg", Referer: "https://markets.hankyung.com/" },
  },
  {
    domains: ["production.dataviz.cnn.io"],   // CNN 공포·탐욕 — 없으면 418(봇)
    headers: { Origin: "https://edition.cnn.com", Referer: "https://edition.cnn.com/", "Accept-Language": "en-US,en;q=0.9" },
  },
  {
    domains: ["query1.finance.yahoo.com", "query2.finance.yahoo.com"],
    headers: { Origin: "https://finance.yahoo.com", Referer: "https://finance.yahoo.com/" },
  },
  {
    domains: ["api.investing.com"],
    headers: {
      "domain-id": "www",
      Origin: "https://www.investing.com",
      Referer: "https://www.investing.com/",
      "Accept-Language": "en-US,en;q=0.9",
    },
  },
];

async function installRules() {
  const rules = HEADER_GROUPS.map((g, i) => ({
    id: i + 1,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: Object.entries(g.headers).map(([header, value]) => ({
        header, operation: "set", value,
      })),
    },
    condition: {
      requestDomains: g.domains,
      tabIds: [-1],                                  // 확장이 보낸 요청만
      resourceTypes: ["xmlhttprequest", "other"],
    },
  }));
  try {
    const old = await chrome.declarativeNetRequest.getSessionRules();
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: old.map(r => r.id),
      addRules: rules,
    });
  } catch (e) {
    console.error("[포트폴리오 프록시] 헤더 규칙 등록 실패", e);
  }
}
chrome.runtime.onInstalled.addListener(installRules);
chrome.runtime.onStartup.addListener(installRules);
installRules();   // 서비스워커가 깨어날 때마다 (세션 규칙은 재시작 시 사라진다)

// ArrayBuffer → base64. 응답을 텍스트로 넘기면 네이버 자금동향(EUC-KR) 이 깨지므로
// 바이트를 그대로 옮기고 디코딩은 앱에 맡긴다. 큰 응답에서 스택이 터지지 않게 청크 단위.
function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let s = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    s += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(s);
}

async function doFetch(msg) {
  let u;
  try { u = new URL(msg.url); } catch { return { error: "invalid-url" }; }
  if (!ALLOWED_HOSTS.has(u.hostname)) return { error: `host-not-allowed: ${u.hostname}` };
  try {
    let url = msg.url;
    // Yahoo 는 쿠키가 필요하고(crumb 발급·검증), 일부 엔드포인트는 crumb 자체가 필요하다.
    const isYahoo = u.hostname.endsWith("yahoo.com");
    if (needsCrumb(u)) {
      const crumb = await getYahooCrumb();
      if (crumb) {
        const withCrumb = new URL(url);
        withCrumb.searchParams.set("crumb", crumb);
        url = withCrumb.toString();
      }
    }
    const init = msg.method === "POST"
      ? { method: "POST", body: msg.body,
          headers: msg.contentType ? { "Content-Type": msg.contentType } : {} }
      : { method: "GET" };
    if (isYahoo) init.credentials = "include";
    const r = await fetch(url, init);
    return {
      status: r.status,
      contentType: r.headers.get("Content-Type") || "application/octet-stream",
      b64: toBase64(await r.arrayBuffer()),
    };
  } catch (e) {
    return { error: String(e && e.message ? e.message : e) };
  }
}

// 툴바 아이콘 클릭 → 앱을 탭으로 연다.
//   팝업(최대 800×600)이나 사이드 패널을 iframe 으로 감싸면 크기 제약과 축소가 따라붙는다.
//   그냥 탭으로 열면 브라우저 크기 그대로라 제약이 없고, 콘텐트 스크립트는 URL 기준으로
//   주입되므로 프록시는 똑같이 동작한다.
//   이미 열려 있으면 새로 만들지 않고 그 탭으로 이동한다.
const APP_URL = "https://hanjungwoo3.github.io/portfolio-web/";

chrome.action.onClicked.addListener(async () => {
  try {
    const [tab] = await chrome.tabs.query({ url: `${APP_URL}*` });
    if (tab) {
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: APP_URL });
    }
  } catch (e) {
    console.error("[포트폴리오] 탭 열기 실패", e);
    chrome.tabs.create({ url: APP_URL });
  }
});

// ─── 구글 액세스 토큰 ────────────────────────────────────────────
// 왜 확장이 해주나 — 웹 페이지에서 GIS 로 조용히 갱신하는 길이 막혔다.
//   prompt:"none" 이어도 GIS 는 팝업을 띄우는데, 만료 타이머에서 부르면 사용자 제스처가
//   없어 브라우저가 그 팝업을 즉시 닫는다(실측: error_callback · popup_closed).
//   그래서 웹만으로는 1시간마다 로그아웃된다.
//   chrome.identity 는 팝업을 안 쓴다 — 한 번 동의하면 interactive:false 로 조용히 재발급된다.
//
// 계정은 크롬 프로필에 로그인된 것을 쓴다(고를 수 없다). 프로필 로그인이 없으면 실패한다.
function getGoogleToken(interactive) {
  return new Promise((resolve) => {
    try {
      chrome.identity.getAuthToken({ interactive: !!interactive }, (token) => {
        const err = chrome.runtime.lastError;
        if (err || !token) { resolve({ error: err ? err.message : "no-token" }); return; }
        // 구글 액세스 토큰은 1시간이다. 확장은 만료 시각을 안 주므로 그렇게 본다.
        resolve({ token, expiresIn: 3600 });
      });
    } catch (e) {
      resolve({ error: String(e) });
    }
  });
}

// 캐시된 토큰 폐기 — 401 을 받았을 때. 안 비우면 크롬이 같은 죽은 토큰을 계속 돌려준다.
function clearGoogleToken(token) {
  return new Promise((resolve) => {
    if (!token) { resolve({ ok: true }); return; }
    try {
      chrome.identity.removeCachedAuthToken({ token }, () => resolve({ ok: true }));
    } catch {
      resolve({ ok: true });
    }
  });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === "ping") { sendResponse({ ok: true }); return; }
  if (msg.type === "fetch") {
    doFetch(msg).then(sendResponse);
    return true;   // 비동기 응답
  }
  if (msg.type === "googleToken") {
    getGoogleToken(msg.interactive).then(sendResponse);
    return true;
  }
  if (msg.type === "googleTokenClear") {
    clearGoogleToken(msg.token).then(sendResponse);
    return true;
  }
});
